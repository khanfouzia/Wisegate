<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>All various kinds of upcoming events will be created under this test suite. All major validations will be in placed.</description>
   <name>Inside Track - Upcoming Events</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-02-16T18:12:03</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>e8a72e10-2498-40a5-92b1-4d9906db9f0f</testSuiteGuid>
   <testCaseLink>
      <guid>665a4858-0dac-4a44-b6e3-61689000a334</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>de184b98-20c5-4915-90d4-0d4b2806588d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Add Upcoming Event</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cddf1d81-3f20-49bf-9a97-e2a815689308</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Navigate to Home Page</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>4b808da6-cf5c-484f-a12a-ad532248275a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Verify Event in Announcement Box</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7e35dd53-c8d3-418a-a714-d97e1d90967c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Navigate to See All Announcements</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>347a5650-90ef-41d0-bda6-cc1158dbe1bc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Verify Upcoming Event Listing on Announcement Page</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>77325267-f526-4085-89b3-c1f16e0be572</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Verify Upcoming Event Details</testCaseId>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>925b9bcf-e9b7-4ea1-ac32-6d76a19742ec</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>d4d87941-18c7-4ae6-816e-e537802133e6</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>14e913d1-a65e-41f9-961c-cc69b0624850</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>345ba225-4653-4ad7-b673-3defc362317e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Logout</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c974359b-ce86-42c9-9014-7649c3790f03</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Verify Upcoming Event List View</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fa7591b1-9323-4ec5-9cfe-f87b34dc2ed9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Navigate to Events</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0188ed2a-1f25-4d2c-9762-2c5a7ac5a035</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Navigate Back to Events</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5e6b3fd3-c8cf-46ba-9450-16d0368837c3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Navigate to See all Upcoming Events</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
