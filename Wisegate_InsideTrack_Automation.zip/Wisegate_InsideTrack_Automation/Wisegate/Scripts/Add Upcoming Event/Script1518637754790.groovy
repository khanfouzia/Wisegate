import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import org.openqa.selenium.JavascriptExecutor as JavascriptExecutor
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import com.kms.katalon.core.testobject.ConditionType as ConditionType

/*WebUI.waitForElementVisible(findTestObject('Page_Uptime Institute  Dashboard/a_Events'), 0)

WebUI.click(findTestObject('Page_Uptime Institute  Dashboard/a_Events'))*/
WebUI.callTestCase(findTestCase('Navigate to Events'), [:], FailureHandling.STOP_ON_FAILURE)

TotalRows = findTestData('EventsInputData').getRowNumbers()

/*KeywordLogger log = new KeywordLogger()
log.logInfo(TotalRows)*/
for (i = 1; i < (TotalRows + 1); ++i) {
    //Moving to events
    WebUI.waitForElementVisible(findTestObject('Page_Uptime Institute  Event List (5)/a_ Add Upcoming Event'), 0)

    //Adding upcoming event
    WebUI.click(findTestObject('Page_Uptime Institute  Event List (5)/a_ Add Upcoming Event'))

	//Waiting for page to be loaded first
	WebUI.waitForPageLoad(10)
	
    //Setting event's title and detail
    Event_Title = findTestData('EventsInputData').getValue('Event Title', i)

    Event_Detail = findTestData('EventsInputData').getValue('Event Detail', i)

    WebUI.setText(findTestObject('Page_Uptime Institute  Create Event (9)/input_event.name'), Event_Title)

    WebUI.setText(findTestObject('Page_Uptime Institute  Create Event (9)/textarea_event.description'), Event_Detail)

    //Getting event's due date field from data table
    String EventDate_Year = findTestData('EventsInputData').getValue('Event Date (year)', i)

    String EventDate_Month = findTestData('EventsInputData').getValue('Event Date (month)', i)

    String EventDate_Day = findTestData('EventsInputData').getValue('Event Date (day)', i)

    def driver = DriverFactory.getWebDriver()

    //Setting event's due Date & Time
    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Event_Year'), 10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, EventDate_Year)

    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Event_Month'), 10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, EventDate_Month)

    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Event_Day'), 10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, EventDate_Day)

    //Combines day/month/year together
    Event_Date_Value = ((((EventDate_Day + '/') + EventDate_Month) + '/') + EventDate_Year)

    //Checks event's type. 0 is for non All day event and 1 is for All day and multi day events
    Event_Number_Of_Days = findTestData('EventsInputData').getValue('Number of days', i)

    //If event is 0 (non All/multi day) then sets event's time field also checks non All/multi day checkbox
    //String Event_Type = '0'
    if (Event_Number_Of_Days == '0') {
		
		if (GlobalVariable.family_id == '4')
			WebUI.click(findTestObject('Object Repository/Page_Uptime Institute  Create Event (9)/div_event.allOrMultiDay'))

        WebUI.delay(2)

        Event_Duration = findTestData('EventsInputData').getValue('Event Duration', i)

        WebUI.setText(findTestObject('Object Repository/Page_Uptime Institute  Create Event (9)/input_event.durationInMinutes'), 
            Event_Duration)

        Event_Time_Hour = findTestData('EventsInputData').getValue('Event Time (Hour)', i)

        Event_Time_Minute = findTestData('EventsInputData').getValue('Event Time (Minute)', i)

        obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Event_Time_Hour'), 
            10)

            ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, Event_Time_Hour)

        obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Event_Time_Minute'), 
            10)

            ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, Event_Time_Minute)

        //Combines event' time fields (Hour and minute)
        Event_Time_Value = (((Event_Time_Hour + ':') + Event_Time_Minute) + ' AM' //Setting number of days in dropdown
        //Event_Type = Event_Number_Of_Days
        )
    } else {
        TestObject Num_Of_days = new TestObject()

        Num_Of_days.addProperty('name', ConditionType.EQUALS, 'event.durationInDays')
		
		if (GlobalVariable.family_id == '2')
			WebUI.click(findTestObject('Object Repository/Page_Uptime Institute  Create Event (9)/div_event.allOrMultiDay'))
		
        obj = WebUiCommonHelper.findWebElement(Num_Of_days, 10)

            ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, Event_Number_Of_Days)

        Event_Time_Value = ((('00' + ':') + '00') + ' AM')
    }
    
    //Setting other Time form mandatory fields
    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Event_DateTime_Attr'), 
        10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, 'struct')

    Event_Date_Time_Value = (((Event_Date_Value + ' (') + Event_Time_Value) + ')')

    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Event_Date_Time_Value'), 
        10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, Event_Date_Time_Value)

    //Checks if notification has to be sent. SenNotis 0 indicates no notification and 1 indicates send
    SendNotis = findTestData('EventsInputData').getValue('Send Notification', i)

    //unnecessary:
    Notis_Year = '0'
	
    if ((SendNotis == '1') && (GlobalVariable.family_id == '4')) {
        WebUI.delay(3)

        //Enables notificaion checkbox
        WebUI.click(findTestObject('Page_Uptime Institute  Create Event (9)/div_event.isNotificationEnable'))

        //Checking if notification has to be send right away or on a specific date & time.
        Notis_Year = findTestData('EventsInputData').getValue('Send Notification (Year)', i)

        if ((Notis_Year != '') && (Notis_Year != '0')) {
            //Defining notification date/time objects and setting values in them
            TestObject SendNotis_Year = new TestObject()

            SendNotis_Year.addProperty('name', ConditionType.EQUALS, 'event.announcementScheduledAt_year')

            obj = WebUiCommonHelper.findWebElement(SendNotis_Year, 10)

                ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, Notis_Year)

            TestObject SendNotis_Month = new TestObject()

            SendNotis_Month.addProperty('name', ConditionType.EQUALS, 'event.announcementScheduledAt_month')

            Notis_Month = findTestData('EventsInputData').getValue('Send Notification (Month)', i)

            obj = WebUiCommonHelper.findWebElement(SendNotis_Month, 10)

                ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, Notis_Month)

            TestObject SendNotis_Day = new TestObject()

            SendNotis_Day.addProperty('name', ConditionType.EQUALS, 'event.announcementScheduledAt_day')

            Notis_Day = findTestData('EventsInputData').getValue('Send Notification (Day)', i)

            obj = WebUiCommonHelper.findWebElement(SendNotis_Day, 10)

                ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, Notis_Day)

            TestObject SendNotis_Hour = new TestObject()

            SendNotis_Hour.addProperty('name', ConditionType.EQUALS, 'event.announcementScheduledAt_hour')

            Notis_Hour = findTestData('EventsInputData').getValue('Notification Time (Hour)', i)

            obj = WebUiCommonHelper.findWebElement(SendNotis_Hour, 10)

                ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, Notis_Hour)

            TestObject SendNotis_Minute = new TestObject()

            SendNotis_Minute.addProperty('name', ConditionType.EQUALS, 'event.announcementScheduledAt_minute')

            Notis_Minute = findTestData('EventsInputData').getValue('Notification Time (Minutes)', i)

            obj = WebUiCommonHelper.findWebElement(SendNotis_Minute, 10)

                ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, Notis_Minute)

            TestObject SendNotis_Attr = new TestObject()

            SendNotis_Attr.addProperty('name', ConditionType.EQUALS, 'event.announcementScheduledAt')

            obj = WebUiCommonHelper.findWebElement(SendNotis_Attr, 10)

                ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, 'struct')

            TestObject SendNotis_Value = new TestObject()

            SendNotis_Value.addProperty('name', ConditionType.EQUALS, 'event.announcementScheduledAt_value')

            SendNotis_Date = ((((Notis_Day + '/') + Notis_Month) + '/') + Notis_Year)

            SendNotis_Date_Time = (((((SendNotis_Date + ' (') + Notis_Hour) + ':') + Notis_Minute) + ' AM)')

            obj = WebUiCommonHelper.findWebElement(SendNotis_Value, 10)

                ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, SendNotis_Date_Time)
        } else {
            String Notis_Year = '0'
        }
    } else {
        String Notis_Year = '0'
    }
    
    //Setting visibility group
    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Visibility'), 10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, 'All Inside Track Members')

    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Visibility_attr'), 10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, 'Public')

    //Setting Event's Category
    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Category_attr'), 10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, 'true')

    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Category_ID'), 10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, '222')

    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Category_Path'), 10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, 'Emerging Technologies')

    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Category_Name'), 10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, 'Emerging Technologies')

    obj = WebUiCommonHelper.findWebElement(findTestObject('Page_Uptime Institute  Create Event (9)/Category_IDs'), 10)

        ((driver) as JavascriptExecutor).executeScript('arguments[0].value=arguments[1]', obj, '222')

    WebUI.delay(1)

    WebUI.click(findTestObject('Page_Uptime Institute  Create Event (9)/input__action_save'))

    //WebUI.delay(2)

    //WebUI.waitForElementPresent(findTestObject('Page_Uptime Institute  Event List (3)/div_New event successfully sav'), 5)
    //if (WebUI.verifyTextPresent('New event successfully saved.', false, FailureHandling.CONTINUE_ON_FAILURE) == 'true') {
	WebUI.waitForPageLoad(10)
	
    WebUI.verifyTextPresent('New event successfully saved.', false, FailureHandling.CONTINUE_ON_FAILURE)

    WebUI.click(findTestObject('Page_Uptime Institute  Create Event (9)/a_Click here'))

    GlobalVariable.rowNum = i

    //KeywordLogger logg = new KeywordLogger()
    //logg.logInfo(GlobalVariable.rowNum.toString())
	if (GlobalVariable.family_id == '4')
    	GlobalVariable.isNotis = SendNotis.toInteger()
		else
		{
		GlobalVariable.isNotis = 1
		Notis_Year = '0'
		}

    if (Notis_Year != '') {
        GlobalVariable.isNotisDate = Notis_Year.toInteger()
    } else {
        GlobalVariable.isNotisDate = 0
    }
    
    GlobalVariable.Event_Number_Of_Days = Event_Number_Of_Days.toInteger()

    WebUI.callTestCase(findTestCase('Verify Upcoming Event Details'), [('rowNum') : GlobalVariable.rowNum, ('isNotis') : GlobalVariable.isNotis
            , ('isNotisDate') : GlobalVariable.isNotisDate, ('EventType') : GlobalVariable.Event_Number_Of_Days], FailureHandling.CONTINUE_ON_FAILURE //WebUI.callTestCase(findTestCase('Verify Upcoming Event Details'), [('rowNum') : i, ('isNotis') : SendNotis, ('isNotisDate') : Notis_Year
        )

    WebUI.callTestCase(findTestCase('Navigate Back to Events from Event Detail'), [:], FailureHandling.CONTINUE_ON_FAILURE)

    //       , ('EventType') : Event_Type], FailureHandling.CONTINUE_ON_FAILURE )
    WebUI.callTestCase(findTestCase('Navigate to See all Upcoming Events'), [:], FailureHandling.CONTINUE_ON_FAILURE)

    WebUI.callTestCase(findTestCase('Verify Upcoming Event List View'), [:], FailureHandling.CONTINUE_ON_FAILURE)

    WebUI.callTestCase(findTestCase('Navigate Back to Events'), [:], FailureHandling.STOP_ON_FAILURE)

    if ((GlobalVariable.isNotis == 1) && (GlobalVariable.isNotisDate == 0)) {
        //Navigate to Home page
        WebUI.callTestCase(findTestCase('Navigate to Home Page'), [:], FailureHandling.CONTINUE_ON_FAILURE)

        // Call Verify Event in Announcement box Function
        WebUI.callTestCase(findTestCase('Verify Event in Announcement Box'), [:], FailureHandling.CONTINUE_ON_FAILURE)

        WebUI.callTestCase(findTestCase('Navigate to See All Announcements'), [:], FailureHandling.CONTINUE_ON_FAILURE)
		
		//GlobalVariable.OpenEventAnnouncement = true

        WebUI.callTestCase(findTestCase('Verify Upcoming Event Listing on Announcement Page'), [:], FailureHandling.CONTINUE_ON_FAILURE)

        WebUI.callTestCase(findTestCase('Navigate to Events'), [:], FailureHandling.STOP_ON_FAILURE)
    }
}

//WebUI.click(findTestObject('Page_Uptime Institute  Event List (3)/div_New event successfully sav'))
//WebUI.click(findTestObject('Object Repository/Page_Uptime Institute  Create Event (9)/a_Home'))
WebUI.callTestCase(findTestCase('Navigate to Home Page'), [:], FailureHandling.CONTINUE_ON_FAILURE)

WebUI.delay(2)

