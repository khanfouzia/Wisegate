import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

import java.text.DateFormat as DateFormat
import java.text.SimpleDateFormat as SimpleDateFormat
import java.util.Date as Date
import java.util.GregorianCalendar as GregorianCalendar
import java.util.Calendar as Calendar
import java.time.LocalTime as LocalTime
import java.time.format.DateTimeFormatter as DateTimeFormatter

import com.kms.katalon.core.testobject.ConditionType
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.By

import java.util.regex.Pattern
import java.util.List

//function to extract integers
def extractInts( String input ) {
	input.findAll( /\d+/ )*.toInteger()
  }

//GlobalVariable.content_id = '25012'
KeywordLogger log = new KeywordLogger()
//WebUI.navigateToUrl('https://uptime-test.wisegateit.com/member/announcement/show/24882?navigateBackToEvents=true&highlightedwords=&pvtAnnouncement=false')

//Wait for page to be loaded first
WebUI.waitForPageLoad(10)

// getting content id below
TestObject event_announcement = new TestObject()
//GlobalVariable.content_id = 24926
//GlobalVariable.content_id = '25051'
content_id_url = "/member/announcement/show/" + GlobalVariable.content_id.toString()
event_announcement.addProperty("href", ConditionType.EQUALS, content_id_url)

flag = WebUI.verifyElementPresent(event_announcement, 5, FailureHandling.CONTINUE_ON_FAILURE)

if (flag == true) //Indicates that announcement has been displayed for event
{
	
	TestObject eventList = new TestObject()
	WebDriver driver = DriverFactory.getWebDriver()
	List<WebElement> rows = driver.findElements(By.xpath('//*[@id="announcements-content"]/div/div/div[1]/div/div'))
	int count = rows.size()
	
	int rowNum = GlobalVariable.rowNum
	//looping around the list elements to verify event's properties
	
	//add xpath property to title object
	TestObject event_announcement_new = new TestObject()
	event_announcement_new.addProperty("xpath", ConditionType.EQUALS, '//*[@id="announcements-content"]/div/div/div[1]/div/div[2]/div[2]/a')
	 
	//defining detail and date objects by xpath
	TestObject announcement_description = new TestObject()
	announcement_description.addProperty('xpath', ConditionType.EQUALS, '//*[@id="announcements-content"]/div/div/div[1]/div/div[1]/div[4]/span')
	
	TestObject dateObj = new TestObject()
	dateObj_url = '//*[@id="announcements-content"]/div/div/div[1]/div/div[1]/div[3]'
	
	for (i=1; i<=count; ++i)
	{
		/*
		 String id = extractInts("https://uptime-test.wisegateit.com/member/announcement/show/24368?navigateBackToEvents=true&highlightedwords=&pvtAnnouncement=false")
		 
		 //id = id.replaceAll("[", "")
		 id = id.replaceAll("\\p{P}","");
		 */
		
		announcement_href = WebUI.getAttribute(event_announcement, 'href')
		//log.logInfo(announcement_href)
		String announcement_id = extractInts(announcement_href)
		announcement_id = announcement_id.replaceAll("\\p{P}","");
		//log.logInfo(announcement_id.toString())
		
		if (announcement_id == GlobalVariable.content_id)
		{
			//Assigning true to variable so that on Announcement list page event announcement could be opened and its fields could be validated
			GlobalVariable.OpenEventAnnouncement = true
			title_xpath = '//*[@id="announcements-content"]/div/div/div[1]/div/div[' + i.toString() + ']/div[2]/a'
			//log.logInfo(title_xpath)
			event_announcement_new_modified = WebUI.modifyObjectProperty(event_announcement_new, 'xpath', 'equals', title_xpath, true)
		
		
			desc_xpath = '//*[@id="announcements-content"]/div/div/div[1]/div/div[' + i.toString() + ']/div[4]/span'
			announcement_description_modified = WebUI.modifyObjectProperty(announcement_description, 'xpath', 'equals', desc_xpath ,true)
		
		
			dateObj_xpath = '//*[@id="announcements-content"]/div/div/div[1]/div/div[' + i.toString() + ']/div[3]'
			dateObj_modified = WebUI.modifyObjectProperty(dateObj, 'xpath', 'equals', dateObj_xpath,
				 ,true)
		
			//String announcement_title = WebUI.getText(event_announcement)
		
			//Below lines verify announcement title
			Event_Title_Value = findTestData('EventsInputData').getValue('Event Title', rowNum)
			WebUI.verifyElementText(event_announcement_new_modified, Event_Title_Value, FailureHandling.CONTINUE_ON_FAILURE)
		
			//Verify announcement detail
			Event_Detail_Value = findTestData('EventsInputData').getValue('Event Detail', rowNum)
			WebUI.verifyElementText(announcement_description_modified, Event_Detail_Value, FailureHandling.CONTINUE_ON_FAILURE)
		
			//Verify date
			Event_Day_value = findTestData('EventsInputData').getValue('Event Date (day)', rowNum)
		
			Event_Month_value = findTestData('EventsInputData').getValue('Event Date (month)', rowNum)
		
			Event_Year_value = findTestData('EventsInputData').getValue('Event Date (year)', rowNum)
		
		
			Event_Date_Value = ((((Event_Day_value + '/') + Event_Month_value) + '/') + Event_Year_value)
		
			Event_Start_Date = Date.parse('dd/MM/yyyy', Event_Date_Value).format('EEEEEEEE, MMMMMMMM dd, yyyy')
		
			Event_Start_Date = 'Event Date: ' + Event_Start_Date.toString()
		
			//To verify the time zone whether EDT or EST
			def df = 'dd/MM/yyyy'
			def EDT_Start = new Date().parse(df, "11/03/2018")
			def EDT_End = new Date().parse(df, "04/11/2018")
		
			if (GlobalVariable.Event_Number_Of_Days > 1) // multi day event
			{
				SimpleDateFormat sdf = new SimpleDateFormat('dd/MM/yyyy')
		
				Calendar c = Calendar.getInstance()
			
				c.setTime(sdf.parse(Event_Date_Value))
			
				c.add(Calendar.DATE, GlobalVariable.Event_Number_Of_Days - 1) // number of days to add
			
				Event_End_Date_Value = sdf.format(c.getTime()) // dt is now the new date
			
				Event_End_Date = Date.parse('dd/MM/yyyy', Event_End_Date_Value).format('EEEEEEEE, MMMMMMM dd, yyyy')
			
				Multi_Day_Event_Date = ((Event_Start_Date + ' - ') + Event_End_Date)
			
				WebUI.verifyElementText(dateObj_modified, Multi_Day_Event_Date, FailureHandling.CONTINUE_ON_FAILURE) // for non all/multi day event - event with start time
				//All day event
				//non All/multi day events
			} else if (GlobalVariable.Event_Number_Of_Days == 1)
			{
				WebUI.verifyElementText(dateObj_modified, Event_Start_Date, FailureHandling.CONTINUE_ON_FAILURE)
				
			}
			  else if (GlobalVariable.Event_Number_Of_Days == 0) {
				Event_Time_Minute = findTestData('EventsInputData').getValue('Event Time (Minute)', rowNum)
			
				Event_Time_Minute_Int = Event_Time_Minute.toInteger()
			
				if (Event_Time_Minute_Int < 10) {
					Event_Time_Minute = ('0' + Event_Time_Minute)
				}
				
				Event_Time_Hour = findTestData('EventsInputData').getValue('Event Time (Hour)', rowNum)
			
				Event_Time_Hour_Int = Event_Time_Hour.toInteger()
			
				if (Event_Time_Hour_Int < 10) {
					Event_Time_Hour = ('0' + Event_Time_Hour)
				}
				
				//Checking for the time zone format whether EDT or EST
				def Event_Date_ = new Date().parse(df, Event_Date_Value)				
				if (Event_Date_ >= EDT_Start && Event_Date_ <= EDT_End)
					TimeZoneFormat = 'EDT'
					else
					TimeZoneFormat = 'EST'
				
				if (Event_Time_Hour_Int < 12) {
					Event_Time_Hour_Minute = (((((' at ' + Event_Time_Hour) + ':') + Event_Time_Minute) + ' AM ') + TimeZoneFormat)
				} else {
					Event_Time_Hour_Minute = (((((' at ' + Event_Time_Hour) + ':') + Event_Time_Minute) + ' PM ') + TimeZoneFormat)
				}
				
				Event_Date_Time = (Event_Start_Date + Event_Time_Hour_Minute)
			
				WebUI.verifyElementText(dateObj_modified, Event_Date_Time, FailureHandling.CONTINUE_ON_FAILURE)
			}
		
			  break
		}
	
	}
	
}



