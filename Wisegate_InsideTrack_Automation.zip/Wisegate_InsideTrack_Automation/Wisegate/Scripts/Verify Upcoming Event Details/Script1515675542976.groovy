import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import org.openqa.selenium.JavascriptExecutor as JavascriptExecutor
import com.kms.katalon.core.logging.KeywordLogger as KeywordLogger
import com.kms.katalon.core.testobject.ConditionType as ConditionType
import java.text.DateFormat as DateFormat
import java.text.SimpleDateFormat as SimpleDateFormat
import java.util.Date as Date
import java.util.GregorianCalendar as GregorianCalendar
import java.util.Calendar as Calendar
import java.time.LocalTime as LocalTime
import java.time.format.DateTimeFormatter as DateTimeFormatter


rowNum = GlobalVariable.rowNum

TestObject event_title = new TestObject()

event_title.addProperty('class', ConditionType.EQUALS, 'discussion-title announcement-name')

//Event_Title = WebUI.getText(event_title)
Event_Title_Value = findTestData('EventsInputData').getValue('Event Title', rowNum)

//Wait for page to be loaded first
WebUI.waitForPageLoad(10)

//WebUI.verifyElementText(event_title, Event_Title)
WebUI.verifyElementText(event_title, Event_Title_Value, FailureHandling.CONTINUE_ON_FAILURE)

//WebUI.verifyElementText(event_title, 'bug', FailureHandling.CONTINUE_ON_FAILURE)
//Verifies detail of event
TestObject event_detail = new TestObject()

event_detail.addProperty('class', ConditionType.EQUALS, 'discussion-subtitle announcement-desc')

//Event_Detail = WebUI.getText(event_detail)
Event_Detail_Value = findTestData('EventsInputData').getValue('Event Detail', rowNum)

WebUI.verifyElementText(event_detail, Event_Detail_Value, FailureHandling.CONTINUE_ON_FAILURE)


//Verifies event due date (All day event only)
TestObject event_date_content = new TestObject()

event_date_content.addProperty('class', ConditionType.EQUALS, 'event-date-content')

//Event_Date_Content = WebUI.getText(event_date_content)
Event_Day_value = findTestData('EventsInputData').getValue('Event Date (day)', rowNum)

Event_Month_value = findTestData('EventsInputData').getValue('Event Date (month)', rowNum)

Event_Year_value = findTestData('EventsInputData').getValue('Event Date (year)', rowNum)

//BElow ifs are probably not required
/*if (Event_Day_value.toInteger() < 10)
	Event_Day_value = '0' + Event_Day_value

if (Event_Month_value.toInteger() < 10)
	Event_Month_value = '0' + Event_Month_value*/
//Combing event day/month/year fields from data sheet together in order to do the comparison
Event_Date_Value = ((((Event_Day_value + '/') + Event_Month_value) + '/') + Event_Year_value)

Event_Start_Date = Date.parse('dd/MM/yyyy', Event_Date_Value).format('EEEEEEEE, MMMMMMMM dd, yyyy')

//To verify the time zone whether EDT or EST
def df = 'dd/MM/yyyy'
def EDT_Start = new Date().parse(df, "11/03/2018")
def EDT_End = new Date().parse(df, "04/11/2018")

if (GlobalVariable.Event_Number_Of_Days > 1) // multi day event
{
    //Integer Event_Number_Of_Days_Int = parseinteger(Event_Number_Of_Days)
    //Adding event number of days in Due date
    SimpleDateFormat sdf = new SimpleDateFormat('dd/MM/yyyy')

    Calendar c = Calendar.getInstance()

    c.setTime(sdf.parse(Event_Date_Value))

    c.add(Calendar.DATE, GlobalVariable.Event_Number_Of_Days - 1 // number of days to add
        )

    Event_End_Date_Value = sdf.format(c.getTime() // dt is now the new date
        )

    Event_End_Date = Date.parse('dd/MM/yyyy', Event_End_Date_Value).format('EEEEEEEE, MMMMMMM dd, yyyy')

    Multi_Day_Event_Date = ((Event_Start_Date + ' - ') + Event_End_Date)

    WebUI.verifyElementText(event_date_content, Multi_Day_Event_Date, FailureHandling.CONTINUE_ON_FAILURE //for all day event
        ) // for non all/multi day event - event with start time
    //All day event
    //non All/multi day events 
} else if (GlobalVariable.Event_Number_Of_Days == 1) {
    WebUI.verifyElementText(event_date_content, Event_Start_Date, FailureHandling.CONTINUE_ON_FAILURE)
} else if (GlobalVariable.Event_Number_Of_Days == 0) {
    Event_Time_Minute = findTestData('EventsInputData').getValue('Event Time (Minute)', rowNum)

    Event_Time_Minute_Int = Event_Time_Minute.toInteger()

    if (Event_Time_Minute_Int < 10) {
        Event_Time_Minute = ('0' + Event_Time_Minute)
    }
    
    Event_Time_Hour = findTestData('EventsInputData').getValue('Event Time (Hour)', rowNum)

    Event_Time_Hour_Int = Event_Time_Hour.toInteger()

    if (Event_Time_Hour_Int < 10) {
        Event_Time_Hour = ('0' + Event_Time_Hour)
    }
	
	/*def df = 'dd/MM/yyyy'
	def EDT_Start = new Date().parse(df, "11/03/2018")
	def EDT_End = new Date().parse(df, "04/11/2018")*/
	
	//Checking for the time zone format whether EDT or EST
	def Event_Date_ = new Date().parse(df, Event_Date_Value)
	if (Event_Date_ >= EDT_Start && Event_Date_ <= EDT_End)
		TimeZoneFormat = 'EDT'
		else
		TimeZoneFormat = 'EST'
    
    if (Event_Time_Hour_Int < 12) {
        Event_Time_Hour_Minute = (((((' at ' + Event_Time_Hour) + ':') + Event_Time_Minute) + ' AM ') + TimeZoneFormat)
    } else {
        Event_Time_Hour_Minute = (((((' at ' + Event_Time_Hour) + ':') + Event_Time_Minute) + ' PM ') + TimeZoneFormat)
    }
    
    Event_Date_Time = (Event_Start_Date + Event_Time_Hour_Minute)

    WebUI.verifyElementText(event_date_content, Event_Date_Time, FailureHandling.CONTINUE_ON_FAILURE)
}

if ((GlobalVariable.isNotis == 1) && (GlobalVariable.isNotisDate > 2017)) {
    WebUI.click(findTestObject('Object Repository/Page_Uptime Institute  Create Event (9)/img (1)'))

    TestObject Announcement_Value = new TestObject()

    Announcement_Value.addProperty('class', ConditionType.EQUALS, 'announcement-schedule-date')

    //Extracting announcement date & time from data table
    Announcement_Day = findTestData('EventsInputData').getValue('Send Notification (Day)', rowNum)

    Announcement_Month = findTestData('EventsInputData').getValue('Send Notification (Month)', rowNum)

    Announcement_Year = findTestData('EventsInputData').getValue('Send Notification (Year)', rowNum)

    Announcement_Hour = findTestData('EventsInputData').getValue('Notification Time (Hour)', rowNum)

    Announcement_Minutes = findTestData('EventsInputData').getValue('Notification Time (Minutes)', rowNum)

    Announcement_Date = ((((Announcement_Day + '/') + Announcement_Month) + '/') + Announcement_Year)

    Announcement_Date_Value = Date.parse('dd/MM/yyyy', Announcement_Date).format('EEE, MMM dd, yyyy')

	String Announcement_Time_Value = '0'
	
    if ((Announcement_Hour.toInteger() == 12) || (Announcement_Hour.toInteger() > 12)) {
        time = ((Announcement_Hour + ':') + Announcement_Minutes)

        //String result = LocalTime.parse(time, DateTimeFormatter.ofPattern("hh:mm a")).format(DateTimeFormatter.ofPattern("HH:mm"));
        String result = LocalTime.parse(time, DateTimeFormatter.ofPattern('HH:mm')).format(DateTimeFormatter.ofPattern('hh:mm a'))
		
		/*def df = 'dd/MM/yyyy'
		def EDT_Start = new Date().parse(df, "11/03/2018")
		def EDT_End = new Date().parse(df, "04/11/2018")*/
		def Date_Value = new Date().parse(df, Announcement_Date)
		
		
		if (Date_Value >= EDT_Start && Date_Value <= EDT_End)
        	Announcement_Time_Value = (result + ' ') + 'EDT'
			else
			Announcement_Time_Value = (result + ' ') + 'EST'

    } 
	else 
	{
		/*def df = 'dd/MM/yyyy'
		def EDT_Start = new Date().parse(df, "11/03/2018")
		def EDT_End = new Date().parse(df, "04/11/2018")*/
		def Date_Value = new Date().parse(df, Announcement_Date)
		
		
		if (Date_Value >= EDT_Start && Date_Value <= EDT_End)
			Announcement_Time_Value = ((((((Announcement_Hour + ':') + Announcement_Minutes) + ' ') + 'AM') + ' ') + 'EDT')
			else
			Announcement_Time_Value = ((((((Announcement_Hour + ':') + Announcement_Minutes) + ' ') + 'AM') + ' ') + 'EST')
	
        //Announcement_Time_Value = ((((((Announcement_Hour + ':') + Announcement_Minutes) + ' ') + 'AM') + ' ') + 'EST')
    }
    
    Announcement_Date_Time = ((((Announcement_Date_Value + ' ') + 'at') + ' ') + Announcement_Time_Value)

    WebUI.verifyElementText(Announcement_Value, Announcement_Date_Time, FailureHandling.CONTINUE_ON_FAILURE)	
	
}
	else
	{
		if (GlobalVariable.family_id == '4')
		{
			WebUI.click(findTestObject('Object Repository/Page_Uptime Institute  Create Event (9)/img (1)'))
			
			//Wait for page to be loaded first
			WebUI.waitForPageLoad(10)
			
			WebUI.verifyTextPresent("Click here to schedule announcement", false)
		}
	}

TestObject event_id = new TestObject()
event_id.addProperty("name", ConditionType.EQUALS, "contentId")
event_id.addProperty("id", ConditionType.EQUALS, "contentId")

String content_id_value = WebUI.getAttribute(event_id, 'value')

GlobalVariable.content_id = content_id_value




