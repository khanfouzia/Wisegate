import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

import java.text.DateFormat as DateFormat
import java.text.SimpleDateFormat as SimpleDateFormat
import java.util.Date as Date
import java.util.GregorianCalendar as GregorianCalendar
import java.util.Calendar as Calendar
import java.time.LocalTime as LocalTime
import java.time.format.DateTimeFormatter as DateTimeFormatter

import com.kms.katalon.core.testobject.ConditionType
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.By

import java.util.regex.Pattern
import java.util.List

import org.openqa.selenium.WebDriver
import org.openqa.selenium.By
import org.openqa.selenium.By.ByClassName
import org.openqa.selenium.By.ByCssSelector
import org.openqa.selenium.WebElement


//WebDriver driver = DriverFactory.getWebDriver()
////Functions below/////

def extractInts( String input ) {
	input.findAll( /\d+/ )*.toInteger()
  }

//// END Functions //////
//WebUI.click(findTestObject('Object Repository/Page_Uptime Institute  Event List/a_See All Upcoming Events'))


//TestObject pageNum = new TestObject()
KeywordLogger log = new KeywordLogger()
int pageindex = 1

//WebUI.delay(3)
//Wait for page to be loaded first
WebUI.waitForPageLoad(10)

flag = true
//WebUI.delay(3)

while (flag == true)
{
	
	if (pageindex.toString() != '1')
	{
		newPageObj = WebUI.modifyObjectProperty(findTestObject('Object Repository/Page_Uptime Institute  Event List/span_2'), 'text', 'equals', pageindex.toString(), true)
		WebUI.click(newPageObj)
		
	}
	WebUI.delay(2)
	pageindex = pageindex+1
	
	String id = GlobalVariable.content_id
	WebDriver driver = DriverFactory.getWebDriver()
	
	List<WebElement> rows = driver.findElements(By.xpath('//*[@id="upcomingevent-grid"]/div[1]/div/table/tbody/tr'))
	//("//table[@class='table table-condensed table-hover event-list']/tbody/tr"))
	int count = rows.size()
	
	loopBreaker = false
	log.logInfo(count.toString())
	for (j= 1; j<=count; j++)
	{
		// getting event id below
		path = '//*[@id="upcomingevent-grid"]/div[1]/div/table/tbody/tr[' + j.toString() + ']'
		path = path.toString()
		event_attr_modified = WebUI.modifyObjectProperty(findTestObject('Object Repository/Page_Uptime Institute  Event List/event_attr'), 'xpath', 'equals', path, true)
		String value = WebUI.getAttribute(event_attr_modified, 'event-id')
		
		if (value == id)
		{
			log.logInfo("inside loop")
			attr_xpath_title = '//*[@id="upcomingevent-grid"]/div[1]/div/table/tbody/tr[' + j.toString() + ']/td/div/div[2]/div[1]/a'
			attr_xpath_title = attr_xpath_title.toString()
			
			//path = path.toString()
			Event_Attr_title_modified = WebUI.modifyObjectProperty(findTestObject('Object Repository/Page_Uptime Institute  Event List/Event_Title'), 'xpath', 'equals', attr_xpath_title, true)
			WebUI.verifyElementPresent(Event_Attr_title_modified, 5)
			
			attr_xpath_date = '//*[@id="upcomingevent-grid"]/div[1]/div/table/tbody/tr[' + j.toString() + ']/td/div/div[2]/div[2]'
			attr_xpath_date = attr_xpath_date.toString()
			Event_Attr_date_modified = WebUI.modifyObjectProperty(findTestObject('Object Repository/Page_Uptime Institute  Event List/Event_date_attr'), 'xpath', 'equals', attr_xpath_date, true)
			
			attr_xpath_desc = '//*[@id="upcomingevent-grid"]/div[1]/div/table/tbody/tr[' + j.toString() +']/td/div/div[2]/div[3]/span'
			attr_xpath_desc = attr_xpath_desc.toString()
			Event_Attr_desc_modified = WebUI.modifyObjectProperty(findTestObject('Object Repository/Page_Uptime Institute  Event List/Event_detail_attr'), 'xpath', 'equals', attr_xpath_desc, true)
		
			int rowNum = GlobalVariable.rowNum
			
			// Below verification of title, description and date sections are repetitive from Test case named 'Verify Upcoming Event Details', especially date validation part
			//Verifies event title
			Event_Title_Value = findTestData('EventsInputData').getValue('Event Title', rowNum)
			WebUI.verifyElementText(Event_Attr_title_modified, Event_Title_Value, FailureHandling.CONTINUE_ON_FAILURE)
			
			//Verfies event description
			Event_Detail_Value = findTestData('EventsInputData').getValue('Event Detail', rowNum)
			WebUI.verifyElementText(Event_Attr_desc_modified, Event_Detail_Value, FailureHandling.CONTINUE_ON_FAILURE)
			
			//Verifies event date
			Event_Day_value = findTestData('EventsInputData').getValue('Event Date (day)', rowNum)
			
			Event_Month_value = findTestData('EventsInputData').getValue('Event Date (month)', rowNum)
			
			Event_Year_value = findTestData('EventsInputData').getValue('Event Date (year)', rowNum)
			
			
			Event_Date_Value = ((((Event_Day_value + '/') + Event_Month_value) + '/') + Event_Year_value)
			
			Event_Start_Date = Date.parse('dd/MM/yyyy', Event_Date_Value).format('EEEEEEEE, MMMMMMMM dd, yyyy')
			
			Event_Start_Date = 'Event Date: ' + Event_Start_Date.toString()
			
			//Checking for time zone format whether EDT or EST
			def df = 'dd/MM/yyyy'
			def EDT_Start = new Date().parse(df, "11/03/2018")
			def EDT_End = new Date().parse(df, "04/11/2018")
			
			if (GlobalVariable.Event_Number_Of_Days > 1) // multi day event
			{
				SimpleDateFormat sdf = new SimpleDateFormat('dd/MM/yyyy')
			
				Calendar c = Calendar.getInstance()
			
				c.setTime(sdf.parse(Event_Date_Value))
			
				c.add(Calendar.DATE, GlobalVariable.Event_Number_Of_Days - 1 // number of days to add
					)
			
				Event_End_Date_Value = sdf.format(c.getTime() // dt is now the new date
					)
			
				Event_End_Date = Date.parse('dd/MM/yyyy', Event_End_Date_Value).format('EEEEEEEE, MMMMMMM dd, yyyy')
			
				Multi_Day_Event_Date = ((Event_Start_Date + ' - ') + Event_End_Date)
			
				WebUI.verifyElementText(Event_Attr_date_modified, Multi_Day_Event_Date, FailureHandling.CONTINUE_ON_FAILURE //for all day event
					) // for non all/multi day event - event with start time
				//All day event
				//non All/multi day events
			} else if (GlobalVariable.Event_Number_Of_Days == 1)
			{
				WebUI.verifyElementText(Event_Attr_date_modified, Event_Start_Date, FailureHandling.CONTINUE_ON_FAILURE)
				
			}
			  else if (GlobalVariable.Event_Number_Of_Days == 0) {
				Event_Time_Minute = findTestData('EventsInputData').getValue('Event Time (Minute)', rowNum)
			
				Event_Time_Minute_Int = Event_Time_Minute.toInteger()
			
				if (Event_Time_Minute_Int < 10) {
					Event_Time_Minute = ('0' + Event_Time_Minute)
				}
				
				Event_Time_Hour = findTestData('EventsInputData').getValue('Event Time (Hour)', rowNum)
			
				Event_Time_Hour_Int = Event_Time_Hour.toInteger()
			
				if (Event_Time_Hour_Int < 10) {
					Event_Time_Hour = ('0' + Event_Time_Hour)
				}
				
				//Checking for time zone format whether EDT or EST
				def Event_Date_ = new Date().parse(df, Event_Date_Value)
				if (Event_Date_ >= EDT_Start && Event_Date_ <= EDT_End)
					TimeZoneFormat = 'EDT'
					else
					TimeZoneFormat = 'EST'
				
				if (Event_Time_Hour_Int < 12) {
					Event_Time_Hour_Minute = (((((' at ' + Event_Time_Hour) + ':') + Event_Time_Minute) + ' am ') + TimeZoneFormat)
				} else {
					Event_Time_Hour_Minute = (((((' at ' + Event_Time_Hour) + ':') + Event_Time_Minute) + ' pm ') + TimeZoneFormat)
				}
				
				Event_Date_Time = (Event_Start_Date + Event_Time_Hour_Minute)
			
				WebUI.verifyElementText(Event_Attr_date_modified, Event_Date_Time, FailureHandling.CONTINUE_ON_FAILURE)
			}
			
			
			/////////Repetition ENDS/////// Verify event date ENDS//////
			
			
			//log.logInfo(i.toString())
			//log.logInfo(j.toString())
			loopBreaker = true
			break
		}
	}
	
	if (loopBreaker == true)
		break		

		newPageObj = WebUI.modifyObjectProperty(findTestObject('Object Repository/Page_Uptime Institute  Event List/span_2'), 'text', 'equals', pageindex.toString(), true)
		flag = WebUI.verifyElementPresent(newPageObj, 5, FailureHandling.CONTINUE_ON_FAILURE)
}
/*
TestObject back_to_events = new TestObject()

back_to_events.addProperty("tag", ConditionType.EQUALS, "span")
back_to_events.addProperty("text", ConditionType.EQUALS, "Back to Events")
WebUI.click(back_to_events)
WebUI.delay(1)
*/

