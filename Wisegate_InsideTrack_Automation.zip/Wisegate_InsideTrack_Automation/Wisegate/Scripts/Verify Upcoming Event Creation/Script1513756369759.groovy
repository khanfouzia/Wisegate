import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint

import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords

import groovy.transform.EqualsAndHashCode

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.logging.KeywordLogger

//below lines have to be deleted later
WebUI.waitForElementVisible(findTestObject('Page_Uptime Institute  Dashboard/a_Events'), 0)

WebUI.click(findTestObject('Page_Uptime Institute  Dashboard/a_Events'))
WebUI.delay(3)
WebUI.waitForElementPresent(findTestObject('Object Repository/Page_Uptime Institute  Event List (1)/a_See All Upcoming Events'), 0)

WebUI.click(findTestObject('Object Repository/Page_Uptime Institute  Event List (1)/a_See All Upcoming Events'))
/*
url_AnnouncementView = 'https://uptime-test.wisegateit.com/member/announcement/show/24039'

url_EventView = url_AnnouncementView + '?navigateBackToEvents=true&highlightedwords=&pvtAnnouncement=false'

KeywordLogger log = new KeywordLogger()
log.logInfo(url_EventView)
*/

WebUI.delay(5)
flag = 'false'

//textVerification = WebUI.verifyTextPresent('Test eventTT', false)
WebUI.verifyTextPresent('Test eventT', false)
TestObject eventObj = new TestObject()
eventObj.addProperty('text', ConditionType.EQUALS, 'Test eventT')
//eventObj.addProperty('onclick', ConditionType.EQUALS, "trackDiscussionShowClicked('event wrap-up', {page:'Event List'});")


if (WebUI.verifyElementPresent(eventObj, 0) == 'true')
{
	WebUI.verifyTextPresent('Test eventTT', false)
	flag = 'true'
}
	else 
	{
		a = 2
		TestObject pageNum = new TestObject()
		pageNum.addProperty("class", ConditionType.EQUALS, "newpage", true)
		pageNum.addProperty("text", ConditionType.EQUALS, "2", true)
		
		while (WebUI.verifyElementPresent(pageNum, 0) == 'true')
		{
			WebUI.click(findTestObject('pageNum'))
			WebUI.delay(5)
			if (WebUI.verifyElementPresent(eventObj, 0) == 'true')
			{
				WebUI.verifyTextPresent('Test eventTT', false)
				flag = 'true'
				exit
			}
				else
					WebUI.modifyObjectProperty(pageNum, 'text', ConditionType.EQUALS, '3', false)
			
		}
	}

if (flag == 'false')
	(WebUI.verifyTextPresent('Test eventTT', false))

//WebUI.click(findTestObject('Page_Uptime Institute  Event List (1)/span_Back to Events'))

WebUI.delay(5)


//WebUI.closeBrowser()


/*
TestObject SignoutObj = new TestObject ()

SignoutObj.addProperty("text", ConditionType.EQUALS, "  Sign Out", true)

SignoutObj.addProperty("tag", ConditionType.EQUALS, "a", true)

WebUI.waitForElementPresent(SignoutObj, 0)

WebUI.click(SignoutObj)
 */

