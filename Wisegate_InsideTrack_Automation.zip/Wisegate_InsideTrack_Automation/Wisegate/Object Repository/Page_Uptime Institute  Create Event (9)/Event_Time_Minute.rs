<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Event_Time_Minute</name>
   <tag></tag>
   <elementGuidId>d2e29847-4002-46ff-835b-fb6557d60d4c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@event.dateTime_minute = 'event.dateTime_minute']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>event.dateTime_minute</value>
   </webElementProperties>
</WebElementEntity>
