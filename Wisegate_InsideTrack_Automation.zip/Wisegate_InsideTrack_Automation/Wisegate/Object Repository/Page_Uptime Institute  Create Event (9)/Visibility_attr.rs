<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>content.privateTopicOrg value needs to be set to Public as per id being posted with form.</description>
   <name>Visibility_attr</name>
   <tag></tag>
   <elementGuidId>4ad782b3-631e-4ed0-8e5e-d54beeb40050</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>content.privateTopicOrg</value>
   </webElementProperties>
</WebElementEntity>
