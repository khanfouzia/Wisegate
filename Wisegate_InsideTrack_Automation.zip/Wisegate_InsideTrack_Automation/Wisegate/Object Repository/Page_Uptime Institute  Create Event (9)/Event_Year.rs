<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Event_Year field belongs to form which is going to be posted.</description>
   <name>Event_Year</name>
   <tag></tag>
   <elementGuidId>634fc5e3-cdf5-4bee-8239-1206362bf9c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>event.dateTime_year</value>
   </webElementProperties>
</WebElementEntity>
