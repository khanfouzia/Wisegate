<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Select Visibility drop down.</description>
   <name>Visibility</name>
   <tag></tag>
   <elementGuidId>bce35a87-7819-4831-bf39-c34b42bd2480</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@name = 'content.privateTopicOrgName']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>content.privateTopicOrgName</value>
   </webElementProperties>
</WebElementEntity>
