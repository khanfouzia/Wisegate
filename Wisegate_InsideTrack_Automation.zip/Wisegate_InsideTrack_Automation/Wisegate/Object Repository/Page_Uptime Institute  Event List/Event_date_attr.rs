<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Event_date_attr</name>
   <tag></tag>
   <elementGuidId>df852ce7-77ff-4e77-83ca-32297ad69184</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'date'][count(. | id(&quot;upcomingevent-grid&quot;)/div[@class=&quot;table_area&quot;]/div[@class=&quot;tablecontent&quot;]/table[@class=&quot;gridContent&quot;]/tbody[1]/tr[@class=&quot;event&quot;]/td[1]/div[@class=&quot;event bottom-border&quot;]/div[@class=&quot;details&quot;]/div[@class=&quot;date&quot;]) = count(id(&quot;upcomingevent-grid&quot;)/div[@class=&quot;table_area&quot;]/div[@class=&quot;tablecontent&quot;]/table[@class=&quot;gridContent&quot;]/tbody[1]/tr[@class=&quot;event&quot;]/td[1]/div[@class=&quot;event bottom-border&quot;]/div[@class=&quot;details&quot;]/div[@class=&quot;date&quot;])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>date</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Event Date: Monday, April 02, 2018 - Sunday, April 08, 2018</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;upcomingevent-grid&quot;)/div[@class=&quot;table_area&quot;]/div[@class=&quot;tablecontent&quot;]/table[@class=&quot;gridContent&quot;]/tbody[1]/tr[@class=&quot;event&quot;]/td[1]/div[@class=&quot;event bottom-border&quot;]/div[@class=&quot;details&quot;]/div[@class=&quot;date&quot;]</value>
   </webElementProperties>
</WebElementEntity>
