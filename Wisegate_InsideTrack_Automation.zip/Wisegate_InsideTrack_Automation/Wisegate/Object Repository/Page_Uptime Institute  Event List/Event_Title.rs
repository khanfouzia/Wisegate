<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Event_Title</name>
   <tag></tag>
   <elementGuidId>c974a230-fb9a-4be9-98ae-56af258c8648</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[count(. | id(&quot;upcomingevent-grid&quot;)/div[@class=&quot;table_area&quot;]/div[@class=&quot;tablecontent&quot;]/table[@class=&quot;gridContent&quot;]/tbody[1]/tr[@class=&quot;event&quot;]/td[1]/div[@class=&quot;event bottom-border&quot;]/div[@class=&quot;details&quot;]/div[@class=&quot;title&quot;]/a[1]) = count(id(&quot;upcomingevent-grid&quot;)/div[@class=&quot;table_area&quot;]/div[@class=&quot;tablecontent&quot;]/table[@class=&quot;gridContent&quot;]/tbody[1]/tr[@class=&quot;event&quot;]/td[1]/div[@class=&quot;event bottom-border&quot;]/div[@class=&quot;details&quot;]/div[@class=&quot;title&quot;]/a[1])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/member/event/show/24331</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onclick</name>
      <type>Main</type>
      <value>trackDiscussionShowClicked('event wrap-up', {page:'Event List'});</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Test2-N </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;upcomingevent-grid&quot;)/div[@class=&quot;table_area&quot;]/div[@class=&quot;tablecontent&quot;]/table[@class=&quot;gridContent&quot;]/tbody[1]/tr[@class=&quot;event&quot;]/td[1]/div[@class=&quot;event bottom-border&quot;]/div[@class=&quot;details&quot;]/div[@class=&quot;title&quot;]/a[1]</value>
   </webElementProperties>
</WebElementEntity>
