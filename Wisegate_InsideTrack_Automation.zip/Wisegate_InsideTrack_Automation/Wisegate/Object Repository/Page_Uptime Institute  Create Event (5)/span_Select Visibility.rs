<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Select Visibility</name>
   <tag></tag>
   <elementGuidId>26a4001e-7d03-4818-96d7-fa2fefd3dca2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'accessmenuSelection'][count(. | //*[text() = 'Select Visibility']) = count(//*[text() = 'Select Visibility'])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>accessmenuSelection</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Select Visibility</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;categorySelectorWrapper-780154&quot;)/div[@class=&quot;suggest_on_event&quot;]/a[@class=&quot;fg-button fg-button-icon-right ui-widget ui-corner-all enterClass accessflyout ui-state-focus&quot;]/span[@class=&quot;accessmenuSelection&quot;]</value>
   </webElementProperties>
</WebElementEntity>
