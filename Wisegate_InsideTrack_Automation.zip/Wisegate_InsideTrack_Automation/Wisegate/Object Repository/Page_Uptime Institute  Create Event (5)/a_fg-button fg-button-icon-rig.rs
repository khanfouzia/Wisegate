<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_fg-button fg-button-icon-rig</name>
   <tag></tag>
   <elementGuidId>3eb6a3f7-55f3-4091-a0e5-a77200421c55</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>10</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fg-button fg-button-icon-right ui-widget ui-corner-all enterClass accessflyout ui-state-focus</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;categorySelectorWrapper-780154&quot;)/div[@class=&quot;suggest_on_event&quot;]/a[@class=&quot;fg-button fg-button-icon-right ui-widget ui-corner-all enterClass accessflyout ui-state-focus&quot;]</value>
   </webElementProperties>
</WebElementEntity>
