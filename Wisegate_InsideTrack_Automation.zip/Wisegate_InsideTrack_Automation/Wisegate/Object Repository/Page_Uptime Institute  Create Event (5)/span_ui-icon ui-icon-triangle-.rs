<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_ui-icon ui-icon-triangle-</name>
   <tag></tag>
   <elementGuidId>f7a0b4e0-7a35-4f9d-bba7-260b449b4387</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ui-icon ui-icon-triangle-1-s</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;categorySelectorWrapper-780154&quot;)/div[@class=&quot;suggest_on_event&quot;]/a[@class=&quot;fg-button fg-button-icon-right ui-widget ui-corner-all enterClass accessflyout ui-state-focus&quot;]/span[@class=&quot;ui-icon ui-icon-triangle-1-s&quot;]</value>
   </webElementProperties>
</WebElementEntity>
