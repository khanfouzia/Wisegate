<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_fg-button fg-button-icon-rig</name>
   <tag></tag>
   <elementGuidId>36d1c6fc-d389-462b-9536-8df0da1fa658</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>10</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fg-button fg-button-icon-right ui-widget ui-corner-all enterClass accessflyout ui-state-focus ui-state-loading</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;categorySelectorWrapper-304560&quot;)/div[@class=&quot;suggest_on_event&quot;]/a[@class=&quot;fg-button fg-button-icon-right ui-widget ui-corner-all enterClass accessflyout ui-state-focus ui-state-loading&quot;]</value>
   </webElementProperties>
</WebElementEntity>
