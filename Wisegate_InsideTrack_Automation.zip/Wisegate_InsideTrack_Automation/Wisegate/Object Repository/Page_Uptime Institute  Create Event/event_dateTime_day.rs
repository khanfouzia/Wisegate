<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>event_dateTime_day</name>
   <tag></tag>
   <elementGuidId>1b5a0543-7a22-462c-8122-9c4fb947de94</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
