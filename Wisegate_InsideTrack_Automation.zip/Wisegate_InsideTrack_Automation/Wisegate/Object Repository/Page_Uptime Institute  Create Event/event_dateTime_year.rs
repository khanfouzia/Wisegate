<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>event_dateTime_year</name>
   <tag></tag>
   <elementGuidId>58bb9c14-ff56-4339-a3da-45f53c439c63</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
