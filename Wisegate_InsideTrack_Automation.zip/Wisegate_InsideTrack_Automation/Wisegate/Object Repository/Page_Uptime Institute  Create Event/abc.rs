<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>abc</name>
   <tag></tag>
   <elementGuidId>23da2ff8-1789-453a-a703-ac4c9d02a478</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
