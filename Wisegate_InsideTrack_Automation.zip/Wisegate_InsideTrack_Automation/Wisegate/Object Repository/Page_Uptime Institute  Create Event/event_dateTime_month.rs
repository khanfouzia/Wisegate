<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>event_dateTime_month</name>
   <tag></tag>
   <elementGuidId>0ac17126-71fa-44e9-94f2-fd22bd723b4d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
